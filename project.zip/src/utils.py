import os
import sys
import numpy as pd
import pandas as pd
from src.exception import CustomException
import dill
from sklearn.model_selection import RandomizedSearchCV
from sklearn.metrics import f1_score


def save_object(file_path,obj):
    try:
        dir_path=os.path.dirname(file_path)

        os.makedirs(dir_path,exist_ok=True)

        with open(file_path,"wb") as file_obj:
            dill.dump(obj, file_obj)

    except Exception as e:
        raise CustomException(e,sys)  

def evaluate_models(X_train,y_train,X_test,y_test,models,param):

    try:
        report={}
        for i in range(len(list(models))):
            model=list(models.values())[i]
            para=param[list(models.keys())[i]]

            rs= RandomizedSearchCV(model,para,cv=3,scoring='f1',n_iter=5)
            rs.fit(X_train,y_train)

            model.set_params(**rs.best_params_)    
            model.fit(X_train,y_train)         #Train Model

            y_train_pred=model.predict(X_train)

            y_test_pred=model.predict(X_test)  

            train_model_score=f1_score(y_train,y_train_pred) 
            test_model_score=f1_score(y_test, y_test_pred)

            report[list(models.keys())[i]]=test_model_score
        return report
    except Exception as e:
        raise CustomException(e,sys)    
    
